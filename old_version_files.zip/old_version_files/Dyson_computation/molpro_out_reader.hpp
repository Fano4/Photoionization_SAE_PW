//
//  molpro_out_reader.hpp
//  Dyson_computation
//
//  Created by Stephan van den Wildenberg on 19/12/16.
//  Copyright © 2016 Stephan van den Wildenberg. All rights reserved.
//

#ifndef molpro_out_reader_hpp
#define molpro_out_reader_hpp

#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include <math.h>
#include <string>
#include <fstream>
#include "computation.hpp"

#endif /* molpro_out_reader_hpp */
