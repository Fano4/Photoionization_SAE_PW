//
//  Global_Var.h
//  Dyson_computation
//
//  Created by Stephan van den Wildenberg on 19/12/16.
//  Copyright © 2016 Stephan van den Wildenberg. All rights reserved.
//

#ifndef Global_Var_h
#define Global_Var_h

#include <stdio.h>
#include <cstdlib>



#endif /* Global_Var_h */
